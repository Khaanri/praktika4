#include "uavsimulator.h"
#include <QNetworkDatagram>
#include <QtMath>
#include <algorithm>
#include <cmath>

UavSimulator::UavSimulator(int system, QObject *parent) : QObject(parent), m_system(system)
{
    m_phase = (system - 1) * 2.7;
    connect(&m_socket, &QUdpSocket::readyRead, this, &UavSimulator::read);
    connect(&m_position, &QTimer::timeout, this, &UavSimulator::position);
    connect(&m_heartbeat, &QTimer::timeout, this, &UavSimulator::heartbeat);
    m_position.setTimerType(Qt::PreciseTimer);
    m_heartbeat.setTimerType(Qt::PreciseTimer);
}

bool UavSimulator::start()
{
    if (m_position.isActive()) return true;
    if (!m_socket.bind(QHostAddress::LocalHost, Lab::simulatorPort(m_system), QUdpSocket::DontShareAddress)) {
        emit event("Ошибка порта: " + m_socket.errorString());
        m_socket.close();
        return false;
    }
    if (!m_time.isValid()) {
        m_time.start();
        sendHeartbeat(MAV_STATE_BOOT);
    }
    m_previousMs = m_time.elapsed();
    position(); heartbeat();
    m_position.start(100); m_heartbeat.start(1000);
    emit runningChanged(true);
    emit event("Телеметрия включена");
    return true;
}
void UavSimulator::stop()
{
    if (!running()) return;
    m_position.stop(); m_heartbeat.stop(); m_socket.close();
    dropAcks(0); m_fault = false; m_corrupt = false; m_heartbeatEnabled = true;
    emit runningChanged(false);
    emit event("Эмулятор отключён");
}
void UavSimulator::transmit(const mavlink_message_t &msg, quint16 port)
{
    auto bytes = MavlinkMessageParser::bytes(msg);
    if (m_corrupt) { bytes[bytes.size()-1] ^= 1; m_corrupt = false; }
    if (m_socket.writeDatagram(bytes, QHostAddress::LocalHost, port) != bytes.size())
        emit event("Ошибка передачи: " + m_socket.errorString());
}
void UavSimulator::heartbeat()
{
    if (m_heartbeatEnabled) sendHeartbeat(m_fault ? MAV_STATE_CRITICAL : MAV_STATE_ACTIVE);
}
void UavSimulator::heartbeatEnabled(bool value)
{
    m_heartbeatEnabled = value;
    if (value && running()) heartbeat();
}
void UavSimulator::dropAcks(int n)
{
    m_dropAcks = n;
    emit ackPolicyChanged(n);
}
void UavSimulator::sendHeartbeat(quint8 state)
{
    mavlink_message_t msg{};
    mavlink_msg_heartbeat_pack_status(m_system, Lab::Component, &m_tx, &msg, MAV_TYPE_QUADROTOR,
        MAV_AUTOPILOT_ARDUPILOTMEGA, MAV_MODE_FLAG_CUSTOM_MODE_ENABLED, 4,
        state);
    transmit(msg);
}
void UavSimulator::fault(bool value)
{
    m_fault = value;
    if (m_position.isActive()) heartbeat();
}

void UavSimulator::position()
{
    const qint64 ms = m_time.elapsed();
    const double dt = (ms - m_previousMs) / 1000.0;
    m_previousMs = ms;
    m_altitude += std::clamp(m_targetAltitude - m_altitude, -5.0 * dt, 5.0 * dt);
    if (m_altitude > 0) m_phase += dt / 9.5;
    const double lat = 55.75222 + 0.00040 * std::sin(m_phase);
    const double lon = 37.61556 + 0.00083 * std::cos(m_phase) + (m_system - 1) * 0.0004;
    mavlink_message_t msg{};
    mavlink_msg_global_position_int_pack_status(m_system, Lab::Component, &m_tx, &msg,
        quint32(ms), qRound(lat*1e7), qRound(lon*1e7), qRound((150+m_altitude)*1000),
        qRound(m_altitude*1000), 0, 0, 0, UINT16_MAX);
    transmit(msg);
}

void UavSimulator::read()
{
    while (m_socket.hasPendingDatagrams()) {
        const auto d = m_socket.receiveDatagram();
        if (d.senderAddress() != QHostAddress::LocalHost || d.senderPort() <= 0) continue;
        mavlink_message_t msg{};
        QString error;
        if (!MavlinkMessageParser::read(d.data(), msg, error) || msg.msgid != MAVLINK_MSG_ID_COMMAND_LONG ||
            msg.sysid != Lab::StationId || msg.compid != Lab::StationComponent) continue;
        mavlink_command_long_t cmd{};
        mavlink_msg_command_long_decode(&msg, &cmd);
        if (cmd.target_system != m_system || cmd.target_component != Lab::Component) continue;
        emit commandReceived(cmd.command, cmd.confirmation, cmd.param7);
        const auto now = m_time.elapsed();
        m_recent.removeIf([now](QMap<quint16, Reply>::iterator it){ return now - it->at >= 10000; });
        auto cached = m_recent.constFind(d.senderPort());
        uint8_t result = MAV_RESULT_ACCEPTED;
        if (cached != m_recent.cend() && cached->command == cmd.command &&
            (cmd.confirmation > 0 || cached->firstSeq == msg.seq) &&
            (cmd.command == MAV_CMD_NAV_LAND || cached->altitude == cmd.param7)) {
            result = cached->result;
        } else {
            if (cmd.command != MAV_CMD_NAV_TAKEOFF && cmd.command != MAV_CMD_NAV_LAND)
                result = MAV_RESULT_UNSUPPORTED;
            else if (m_fault) result = MAV_RESULT_DENIED;
            else if (cmd.command == MAV_CMD_NAV_LAND) m_targetAltitude = 0;
            else if (std::isfinite(cmd.param7) && cmd.param7 >= 10 && cmd.param7 <= 500) m_targetAltitude = cmd.param7;
            else result = MAV_RESULT_DENIED;
            m_recent.insert(d.senderPort(),{cmd.command,msg.seq,cmd.param7,result,now});
        }
        if (m_dropAcks != 0) { if (m_dropAcks > 0) dropAcks(m_dropAcks - 1); continue; }
        mavlink_message_t ack{};
        mavlink_msg_command_ack_pack_status(m_system, Lab::Component, &m_tx, &ack,
            cmd.command, result, 255, 0, msg.sysid, msg.compid);
        transmit(ack, d.senderPort());
    }
}
