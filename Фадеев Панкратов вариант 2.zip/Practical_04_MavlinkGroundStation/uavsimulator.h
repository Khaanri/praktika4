#pragma once
#include "parser.h"
#include <QObject>
#include <QMap>
#include <QUdpSocket>
#include <QTimer>
#include <QElapsedTimer>

class UavSimulator : public QObject {
    Q_OBJECT
public:
    explicit UavSimulator(int system, QObject *parent = nullptr);
    bool start();
    void stop();
    bool running() const { return m_position.isActive(); }
    void corrupt() { if (running()) m_corrupt = true; }
    void skipTwo() { if (running()) m_tx.current_tx_seq += 2; }
    void dropAcks(int n);
    void fault(bool value);
    void heartbeatEnabled(bool value);
signals:
    void event(QString text);
    void runningChanged(bool running);
    void ackPolicyChanged(int count);
    void commandReceived(int command, int confirmation, float altitude);
private:
    void read();
    void heartbeat();
    void sendHeartbeat(quint8 state);
    void position();
    void transmit(const mavlink_message_t &message, quint16 port = Lab::StationPort);
    struct Reply { quint16 command; quint8 firstSeq; float altitude; quint8 result; qint64 at; };
    QMap<quint16, Reply> m_recent;
    int m_system, m_dropAcks = 0;
    QUdpSocket m_socket;
    QTimer m_position, m_heartbeat;
    QElapsedTimer m_time;
    qint64 m_previousMs = 0;
    mavlink_status_t m_tx{};
    bool m_corrupt = false, m_fault = false, m_heartbeatEnabled = true;
    double m_altitude = 0, m_targetAltitude = 0, m_phase = 0;
};
