#include "telemetrymodel.h"
#include <QtMath>

TelemetryModel::TelemetryModel(QObject *parent) : QObject(parent) { m_clock.start(); }

std::optional<qint64> TelemetryModel::observe(Vehicle &v, quint8 seq)
{
    if (v.sequence < 0) v.sequence = 256 + seq;
    const int delta = (seq - (v.sequence % 256) + 256) % 256;
    const qint64 stamp = v.sequence + (delta >= 128 ? delta - 256 : delta);
    if (v.seen.contains(stamp)) return {};
    v.seen.insert(stamp);
    if (stamp > v.sequence) {
        for (qint64 i = v.sequence + 1; i < stamp; ++i) v.gaps.insert(i);
        v.lost += stamp - v.sequence - 1;
        v.sequence = stamp;
        const auto expired = [stamp](qint64 n) { return n <= stamp - 128; };
        v.gaps.removeIf(expired);
        v.seen.removeIf(expired);
    } else if (v.gaps.remove(stamp)) --v.lost;
    return stamp;
}

void TelemetryModel::receive(const mavlink_message_t &msg, const QString &address, quint16 port)
{
    const int id = key(msg.sysid, msg.compid);
    Vehicle &v = m_vehicles[id];
    const qint64 time = now();
    const bool gap = v.packetMs >= 0 && time - v.packetMs > 3000;
    const bool position = msg.msgid == MAVLINK_MSG_ID_GLOBAL_POSITION_INT;
    mavlink_global_position_int_t pos{};
    bool reboot = false;
    if (position) {
        mavlink_msg_global_position_int_decode(&msg, &pos);
        reboot = v.bootNoticeMs >= 0 && time - v.bootNoticeMs < 1500 && pos.time_boot_ms < 1500 &&
                 v.lastBootMs && qint32(pos.time_boot_ms - *v.lastBootMs) <= 0;
        v.bootNoticeMs = -1;
    }
    if (gap || reboot) {
        v.sequence = -1; v.heartbeatSequence = -1;
        v.gaps.clear(); v.seen.clear(); v.lastBootMs.reset(); v.bootNoticeMs = -1;
        v.positionMs = -1; v.track.clear(); v.heights.clear(); v.positionsMs.clear(); ++v.revision;
        const bool wasOnline = v.online;
        v.online = false; v.critical = false; v.mode = "—";
        if (reboot) {
            v.heartbeatMs = -1;
            emit event(QString("БПЛА %1 — эмулятор перезапущен").arg(msg.sysid));
            emit restarted(id);
        } else if (wasOnline) {
            emit event(QString("БПЛА %1 — связь потеряна (пауза в данных)").arg(msg.sysid));
        }
    }
    v.system = msg.sysid; v.component = msg.compid; v.address = address; v.port = port;
    v.packetMs = time; v.lastClock = QTime::currentTime(); ++v.received;
    v.errors += m_unidentifiedErrors.take(port);
    if (position) v.positionsMs.enqueue(time);
    if (msg.msgid == MAVLINK_MSG_ID_HEARTBEAT && msg.seq == 0 &&
        mavlink_msg_heartbeat_get_system_status(&msg) == MAV_STATE_BOOT) {
        v.bootNoticeMs = time;
        if (!v.lastBootMs) observe(v, msg.seq);
        refresh();
        return;
    }
    const quint64 before = v.lost;
    auto stamp = observe(v, msg.seq);
    if (v.lost > before)
        emit event(QString("БПЛА %1 — пропуск seq: %2").arg(v.system).arg(v.lost - before));
    if (stamp && msg.msgid == MAVLINK_MSG_ID_HEARTBEAT && *stamp > v.heartbeatSequence) {
        mavlink_heartbeat_t hb{};
        mavlink_msg_heartbeat_decode(&msg, &hb);
        v.heartbeatSequence = *stamp;
        v.heartbeatMs = time;
        if (!v.online) emit event(QString("БПЛА %1 — связь установлена").arg(v.system));
        v.online = true;
        const bool critical = hb.system_status == MAV_STATE_CRITICAL;
        if (critical != v.critical)
            emit event(QString("БПЛА %1 — %2").arg(v.system).arg(critical ? "отказ датчика" : "датчик исправен"));
        v.critical = critical;
        v.mode = (hb.base_mode & MAV_MODE_FLAG_CUSTOM_MODE_ENABLED) && hb.custom_mode == 4
            ? "GUIDED" : QString::number(hb.custom_mode);
    }
    if (position && (reboot || !v.lastBootMs || qint32(pos.time_boot_ms - *v.lastBootMs) > 0)) {
        v.positionMs = time;
        v.lastBootMs = pos.time_boot_ms;
        v.latitude = pos.lat / 1e7; v.longitude = pos.lon / 1e7; v.altitude = pos.alt / 1000.0;
        constexpr double radius = 6371000.0;
        const double x = radius * qDegreesToRadians(v.longitude - 37.61556) * qCos(qDegreesToRadians(55.75222));
        const double y = -radius * qDegreesToRadians(v.latitude - 55.75222);
        v.track.append({x, y}); v.heights.append({time / 1000.0, v.altitude});
        if (v.track.size() > 300) { v.track.removeFirst(); v.heights.removeFirst(); }
        ++v.revision;
    }
    refresh();
}

void TelemetryModel::refresh()
{
    const auto time = now();
    for (auto &v : m_vehicles) {
        while (!v.positionsMs.isEmpty() && v.positionsMs.head() <= time - 1000)
            v.positionsMs.dequeue();
        if (v.online && time - v.heartbeatMs > 3000) {
            v.online = false;
            emit event(QString("БПЛА %1 — связь потеряна (нет HEARTBEAT)").arg(v.system));
        }
    }
    emit changed();
}

void TelemetryModel::errorFrom(quint16 port)
{
    for (auto &v : m_vehicles) {
        if (v.port == port) { ++v.errors; emit changed(); return; }
    }
    ++m_unidentifiedErrors[port];
}

void TelemetryModel::reset()
{
    m_vehicles.clear(); m_unidentifiedErrors.clear();
    emit changed();
}
