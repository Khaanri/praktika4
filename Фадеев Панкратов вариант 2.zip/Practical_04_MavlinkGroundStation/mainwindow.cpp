#include "mainwindow.h"
#include <QtWidgets>
#include <QtCharts/QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QLineSeries>
#include <QtCharts/QValueAxis>
#include <algorithm>
#include <cmath>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent)
{
    setWindowTitle("Наземная станция управления");
    auto *body = new QWidget;
    m_scroll = new QScrollArea;
    m_scroll->setWidgetResizable(false);
    m_scroll->setFrameShape(QFrame::NoFrame);
    m_scroll->setWidget(body);
    setCentralWidget(m_scroll);
    auto *layout = new QVBoxLayout(body);
    layout->setSizeConstraint(QLayout::SetNoConstraint);
    auto *network = new QHBoxLayout;
    m_open = new QPushButton("Открыть канал"); m_open->setObjectName("open");
    m_close = new QPushButton("Закрыть канал"); m_close->setObjectName("closeChannel");
    m_link = new QLabel; m_link->setObjectName("link"); m_link->setWordWrap(true);
    network->addWidget(m_open); network->addWidget(m_close); network->addWidget(m_link, 1);
    layout->addLayout(network);
    m_table = new QTableWidget(0, 7); m_table->setObjectName("vehicles");
    m_table->setHorizontalHeaderLabels({"№","System ID","Component ID","Адрес","Порт","Последний пакет","Статус"});
    m_table->horizontalHeader()->setSectionResizeMode(QHeaderView::ResizeToContents);
    m_table->horizontalHeader()->setSectionResizeMode(3,QHeaderView::Stretch);
    m_table->horizontalHeader()->setSectionResizeMode(5,QHeaderView::Stretch);
    m_table->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_table->setAlternatingRowColors(true);
    m_table->verticalHeader()->hide();
    m_table->setEditTriggers(QAbstractItemView::NoEditTriggers);
    m_table->setSelectionBehavior(QAbstractItemView::SelectRows);
    m_table->setSelectionMode(QAbstractItemView::SingleSelection);
    m_table->setMinimumHeight(92);
    m_table->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Fixed);
    layout->addWidget(m_table);
    m_position = new QLabel; m_metrics = new QLabel;
    m_position->setObjectName("position"); m_metrics->setObjectName("metrics");
    m_position->setWordWrap(true); m_metrics->setWordWrap(true);
    layout->addWidget(m_position); layout->addWidget(m_metrics);

    m_plots = new QBoxLayout(QBoxLayout::LeftToRight);
    auto *mapBox = new QGroupBox("Карта траекторий"); auto *mapLayout = new QVBoxLayout(mapBox);
    m_scene = new QGraphicsScene(this); m_scene->setSceneRect(-100,-62,200,124);
    m_map = new QGraphicsView(m_scene); m_map->setObjectName("map");
    m_map->setMinimumSize(170,125);
    m_map->setRenderHint(QPainter::Antialiasing);
    m_map->setHorizontalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_map->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
    m_scene->addLine(-100,0,100,0,QPen(Qt::lightGray,0));
    m_scene->addLine(0,-62,0,62,QPen(Qt::lightGray,0));
    mapLayout->addWidget(m_map);
    auto *legend = new QLabel("Север ↑   Восток →     1 — синий, 2 — оранжевый");
    legend->setWordWrap(true); mapLayout->addWidget(legend);
    m_plots->addWidget(mapBox, 1);

    m_series = new QLineSeries; m_series->setObjectName("heights");
    auto *chart = new QChart; m_chart = chart; chart->addSeries(m_series); chart->legend()->hide();
    chart->setMargins(QMargins(3,2,6,2));
    m_timeAxis = new QValueAxis; m_timeAxis->setTitleText("Время, с");
    m_heightAxis = new QValueAxis; m_heightAxis->setTitleText("Высота, м");
    chart->addAxis(m_timeAxis,Qt::AlignBottom); chart->addAxis(m_heightAxis,Qt::AlignLeft);
    m_timeAxis->setLabelFormat("%.1f"); m_heightAxis->setLabelFormat("%.1f");
    m_series->attachAxis(m_timeAxis); m_series->attachAxis(m_heightAxis);
    auto *heightBox = new QGroupBox("Высота над уровнем моря");
    auto *heightLayout = new QVBoxLayout(heightBox);
    auto *view = new QChartView(chart); view->setMinimumSize(230,160); view->setRenderHint(QPainter::Antialiasing);
    heightLayout->addWidget(view); m_plots->addWidget(heightBox,1); layout->addLayout(m_plots,1);

    auto *commands = new QHBoxLayout; commands->addWidget(new QLabel("Высота взлёта от старта"));
    m_altitude = new QSpinBox; m_altitude->setObjectName("altitude");
    m_altitude->setRange(10,500); m_altitude->setSingleStep(10); m_altitude->setValue(50); m_altitude->setSuffix(" м");
    m_takeoff = new QPushButton("Взлёт"); m_takeoff->setObjectName("takeoff");
    m_land = new QPushButton("Посадка"); m_land->setObjectName("land"); m_result = new QLabel("Команд нет"); m_result->setObjectName("result");
    commands->addWidget(m_altitude); commands->addWidget(m_takeoff); commands->addWidget(m_land);
    commands->addStretch(); layout->addLayout(commands);
    m_result->setWordWrap(true); layout->addWidget(m_result);
    layout->addWidget(new QLabel("Журнал событий"));
    m_log = new QListWidget; m_log->setObjectName("log"); m_log->setFixedHeight(90); layout->addWidget(m_log);

    connect(m_open,&QPushButton::clicked,&m_manager,&MavlinkManager::open);
    connect(m_close,&QPushButton::clicked,&m_manager,&MavlinkManager::close);
    connect(m_takeoff,&QPushButton::clicked,this,[this]{ m_manager.send(selectedKey(), MAV_CMD_NAV_TAKEOFF, m_altitude->value()); });
    connect(m_land,&QPushButton::clicked,this,[this]{ m_manager.send(selectedKey(), MAV_CMD_NAV_LAND, 0); });
    connect(&m_manager,&MavlinkManager::event,this,&MainWindow::log);
    connect(&m_model,&TelemetryModel::event,this,&MainWindow::log);
    connect(&m_model,&TelemetryModel::changed,this,&MainWindow::refresh);
    connect(&m_manager,&MavlinkManager::changed,this,&MainWindow::refresh);
    connect(m_table,&QTableWidget::itemSelectionChanged,this,&MainWindow::refresh);
    resize(900,660); refresh();
}

void MainWindow::changeEvent(QEvent *event)
{
    QMainWindow::changeEvent(event);
    if (m_chart && (event->type() == QEvent::PaletteChange || event->type() == QEvent::StyleChange)) {
        m_darkPlot.reset();
        QTimer::singleShot(0, this, &MainWindow::refresh);
    }
}

void MainWindow::resizeEvent(QResizeEvent *event)
{
    QMainWindow::resizeEvent(event);
    const bool narrow = width() < 740;
    m_plots->setDirection(narrow ? QBoxLayout::TopToBottom : QBoxLayout::LeftToRight);
    m_table->setHorizontalHeaderLabels(narrow
        ? QStringList{"№","Sys ID","Comp ID","Адрес","Порт","Получен","Статус"}
        : QStringList{"№","System ID","Component ID","Адрес","Порт","Последний пакет","Статус"});
    m_table->horizontalHeader()->setMinimumSectionSize(narrow ? 30 : 42);
    QTimer::singleShot(0, this, &MainWindow::refresh);
}

void MainWindow::log(const QString &message)
{
    m_log->insertItem(0, QTime::currentTime().toString("hh:mm:ss") + "   " + message);
    if (m_log->count() > 100) delete m_log->takeItem(100);
}

int MainWindow::selectedKey() const
{
    if (!m_table->selectionModel()->hasSelection()) return -1;
    auto *item = m_table->item(m_table->currentRow(),0);
    return item ? item->data(Qt::UserRole).toInt() : -1;
}

void MainWindow::refresh()
{
    const QSignalBlocker blocker(m_table);
    const auto &vehicles = m_model.vehicles();
    const int previous = selectedKey();
    const int oldRowCount = m_table->rowCount();
    m_table->setRowCount(vehicles.size());
    int row = 0, selected = -1;
    for (auto it = vehicles.cbegin(); it != vehicles.cend(); ++it, ++row) {
        const auto &v = it.value();
        if (it.key() == previous) selected = row;
        QStringList cells = {QString::number(row+1),QString::number(v.system),QString::number(v.component),
            v.address,QString::number(v.port),v.lastClock.isValid()?v.lastClock.toString("hh:mm:ss"):"—",v.online ? "Online" : (v.heartbeatMs < 0 ? "Ожидание" : "Offline")};
        for (int c = 0; c < cells.size(); ++c) {
            auto *item = m_table->item(row,c);
            if (!item) { item = new QTableWidgetItem; m_table->setItem(row,c,item); }
            if (item->text() != cells[c]) item->setText(cells[c]);
        }
        m_table->item(row,0)->setData(Qt::UserRole,it.key());
    }
    if (row && oldRowCount == 0) m_table->selectRow(0);
    else if (selected >= 0 && selected != m_table->currentRow()) m_table->selectRow(selected);
    const bool narrow = width() < 740;
    const bool compressed = m_table->viewport()->width() < (narrow ? 510 : 670);
    for (int column : {3,5}) {
        auto mode = compressed ? QHeaderView::ResizeToContents : QHeaderView::Stretch;
        if (m_table->horizontalHeader()->sectionResizeMode(column) != mode)
            m_table->horizontalHeader()->setSectionResizeMode(column,mode);
    }
    const int barHeight = m_table->horizontalHeader()->length() > m_table->viewport()->width()
        ? m_table->style()->pixelMetric(QStyle::PM_ScrollBarExtent) : 0;
    m_table->setFixedHeight(m_table->horizontalHeader()->height() +
        2 * m_table->verticalHeader()->defaultSectionSize() + 2 * m_table->frameWidth() + barHeight);
    auto it = vehicles.constFind(selectedKey());
    const bool known = it != vehicles.cend(), online = known && it->online;
    QString link = "Связь отсутствует";
    if (online) link = "Связь установлена";
    else if (known && it->heartbeatMs >= 0) link = "Связь потеряна";
    if (!known && !vehicles.isEmpty()) link = "Выберите БПЛА";
    else if (known && it->heartbeatMs < 0) link = "Ожидание HEARTBEAT";
    if (known) link = QString("БПЛА %1 — ").arg(it->system) + link;
    if (!known && vehicles.isEmpty() && m_manager.isOpen()) link = "Ожидание телеметрии";
    const bool failed = !m_manager.channelError().isEmpty() || (known && !online && it->heartbeatMs >= 0);
    const bool dark = palette().color(QPalette::Window).lightness() < 128;
    QPalette statusPalette = palette();
    if (failed || online) statusPalette.setColor(QPalette::WindowText,
        failed ? QColor(dark ? "#ffaaa0" : "#94281c") : QColor(dark ? "#9ee2ae" : "#175b32"));
    if (m_link->palette() != statusPalette) m_link->setPalette(statusPalette);
    m_link->setText(m_manager.channelError().isEmpty()
        ? link + (m_manager.isOpen() ? "   ·   UDP 14540 открыт" : "   ·   порт закрыт")
        : m_manager.channelError());
    m_open->setEnabled(!m_manager.isOpen()); m_close->setEnabled(m_manager.isOpen());
    m_takeoff->setEnabled(online && !m_manager.busy()); m_land->setEnabled(m_takeoff->isEnabled());
    m_altitude->setEnabled(m_takeoff->isEnabled());
    if (m_manager.busy() && m_manager.activeVehicle() != selectedKey())
        m_result->setText(QString("Ожидается ответ БПЛА %1").arg(m_manager.activeVehicle() / 256));
    else m_result->setText(m_manager.status(selectedKey()));
    if (!known) { m_position->setText("Телеметрия —"); m_metrics->setText("Пакеты —"); }
    if (known) {
        QString summary = it->track.isEmpty() ? QString("Координаты пока не получены")
            : QString("Широта %1°     Долгота %2°     Высота %3 м")
                .arg(it->latitude,0,'f',7).arg(it->longitude,0,'f',7).arg(it->altitude,0,'f',1);
        if (it->positionMs >= 0 && m_model.now() - it->positionMs > 3000)
            summary += "  (последние координаты)";
        m_position->setText(QString("БПЛА %1     %2     Режим %3%4").arg(it->system)
            .arg(summary,it->mode,it->critical ? "     ОТКАЗ ДАТЧИКА" : ""));
        const auto age = it->packetMs < 0 ? QString("—") : QString::number(m_model.now() - it->packetMs) + " мс";
        m_metrics->setText(QString("Принято %1     Ошибок %2     Потеряно %3     Телеметрия %4 Гц     С последнего пакета %5")
            .arg(it->received).arg(it->errors).arg(it->lost).arg(it->positionsMs.size()).arg(age));
    }
    auto *body = m_scroll->widget();
    const int width = qMax(m_scroll->viewport()->width(), body->minimumSizeHint().width());
    // Графики занимают свободное место. На малом экране добавляем прокрутку
    // только там, где минимальные размеры элементов действительно не помещаются.
    int height = body->minimumSizeHint().height() + 8;
    for (auto *label : {m_link, m_position, m_metrics, m_result}) {
        const int available = label == m_link
            ? width - m_open->sizeHint().width() - m_close->sizeHint().width() - 44 : width - 22;
        height += qMax(0, label->heightForWidth(qMax(80,available)) - label->minimumSizeHint().height());
    }
    body->resize(width, qMax(m_scroll->viewport()->height(),height));
    plot();
}

void MainWindow::plot()
{
    const auto &vehicles = m_model.vehicles();
    const bool dark = palette().color(QPalette::Base).lightness() < 128;
    const bool paletteChanged = m_darkPlot != dark;
    if (paletteChanged) {
        m_darkPlot = dark;
        const auto base = palette().brush(QPalette::Base);
        const auto ink = palette().brush(QPalette::Text);
        const auto grid = dark ? QColor("#454951") : QColor("#d6d8dc");
        m_chart->setBackgroundBrush(base); m_chart->setBackgroundRoundness(0);
        m_map->setBackgroundBrush(base);
        for (auto *axis : {m_timeAxis,m_heightAxis}) {
            axis->setLabelsBrush(ink); axis->setTitleBrush(ink);
            axis->setGridLineColor(grid); axis->setLinePenColor(grid);
        }
        for (auto *item : m_scene->items())
            if (auto *line = qgraphicsitem_cast<QGraphicsLineItem *>(item)) line->setPen(QPen(grid,0));
        m_series->setColor(dark ? QColor("#73baff") : QColor("#215a93"));
    }
    if (vehicles.isEmpty()) {
        for (const auto &items : std::as_const(m_items)) { delete items.marker; delete items.path; }
        m_items.clear();
    }
    for (auto it = vehicles.cbegin(); it != vehicles.cend(); ++it) {
        const auto &v = it.value();
        if (v.track.isEmpty()) {
            if (m_items.contains(it.key())) {
                auto items = m_items.take(it.key()); delete items.marker; delete items.path;
            }
            continue;
        }
        const QColor color = v.system == 1 ? QColor(dark ? "#73baff" : "#215a93")
                                           : QColor(dark ? "#ffad71" : "#a9531c");
        if (!m_items.contains(it.key())) {
            auto *path = m_scene->addPath({},QPen(color,1));
            auto *marker = m_scene->addEllipse(-2,-2,4,4,QPen(color),QBrush(color));
            marker->setZValue(1); marker->setToolTip(QString("БПЛА %1").arg(v.system));
            m_items.insert(it.key(),{marker,path});
        }
        auto &items = m_items[it.key()];
        if (paletteChanged) {
            items.path->setPen(QPen(color,1)); items.marker->setPen(QPen(color)); items.marker->setBrush(color);
        }
        if (items.revision != v.revision) {
            QPainterPath path(v.track.first());
            for (int i=1; i<v.track.size(); ++i) path.lineTo(v.track[i]);
            items.path->setPath(path); items.marker->setPos(v.track.last());
            items.revision = v.revision;
        }
        items.marker->setOpacity(v.online ? 1.0 : 0.35);
    }
    m_map->fitInView(m_scene->sceneRect(),Qt::KeepAspectRatio);
    auto it = vehicles.constFind(selectedKey());
    if (it == vehicles.cend() || it->heights.isEmpty()) {
        m_chartKey = -1; m_chartRevision = 0;
        m_series->clear(); m_timeAxis->setRange(0,10); m_heightAxis->setRange(145,155); return;
    }
    if (m_chartKey == it.key() && m_chartRevision == it->revision) return;
    m_chartKey = it.key(); m_chartRevision = it->revision;
    m_series->replace(it->heights);
    auto byY = [](QPointF a, QPointF b){ return a.y() < b.y(); };
    auto bounds = std::minmax_element(it->heights.cbegin(),it->heights.cend(),byY);
    m_timeAxis->setRange(it->heights.first().x(),std::max(it->heights.first().x()+1,it->heights.last().x()));
    m_heightAxis->setRange(std::floor(bounds.first->y())-2,std::ceil(bounds.second->y())+2);
}
