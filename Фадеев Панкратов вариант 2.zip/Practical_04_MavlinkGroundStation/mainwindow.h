#pragma once
#include "mavlinkmanager.h"
#include <QMainWindow>
class QChart;
class QBoxLayout;
class QScrollArea;
class QGraphicsView;
class QGraphicsScene;
class QGraphicsEllipseItem;
class QGraphicsPathItem;
class QTableWidget;
class QLabel;
class QListWidget;
class QSpinBox;
class QPushButton;
class QLineSeries;
class QValueAxis;
class MainWindow : public QMainWindow {
    Q_OBJECT
public:
    explicit MainWindow(QWidget *parent = nullptr);
protected:
    void changeEvent(QEvent *event) override;
    void resizeEvent(QResizeEvent *event) override;
private:
    struct MapItems { QGraphicsEllipseItem *marker; QGraphicsPathItem *path; quint64 revision = 0; };
    void refresh();
    void plot();
    void log(const QString &message);
    int selectedKey() const;
    TelemetryModel m_model;
    MavlinkManager m_manager{&m_model};
    QTableWidget *m_table;
    QScrollArea *m_scroll;
    QBoxLayout *m_plots;
    int m_chartKey = -1;
    quint64 m_chartRevision = 0;
    QLabel *m_link, *m_position, *m_metrics, *m_result;
    QPushButton *m_open, *m_close, *m_takeoff, *m_land;
    QSpinBox *m_altitude;
    QListWidget *m_log;
    QGraphicsView *m_map;
    QGraphicsScene *m_scene;
    QMap<int, MapItems> m_items;
    QChart *m_chart = nullptr;
    std::optional<bool> m_darkPlot;
    QLineSeries *m_series;
    QValueAxis *m_timeAxis, *m_heightAxis;
};
