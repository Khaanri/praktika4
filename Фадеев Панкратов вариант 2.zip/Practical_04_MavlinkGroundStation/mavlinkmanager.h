#pragma once
#include "telemetrymodel.h"
#include <QTimer>
#include <QUdpSocket>

class MavlinkManager : public QObject {
    Q_OBJECT
public:
    explicit MavlinkManager(TelemetryModel *model, QObject *parent = nullptr);
    bool open();
    void close();
    bool isOpen() const { return m_socket.state() == QAbstractSocket::BoundState; }
    bool busy() const { return m_reply != nullptr; }
    int activeVehicle() const { return busy() ? m_vehicle : -1; }
    QString status(int key) const { return m_results.value(key, "Команд нет"); }
    QString channelError() const { return m_channelError; }
    void send(int vehicle, quint16 command, double altitude);
signals:
    void event(QString message);
    void changed();
private:
    void read(QUdpSocket *socket);
    void attempt();
    void finish(const QString &text);
    void report(const QString &text);
    void handleAck(const mavlink_message_t &msg);
    bool reachable(int vehicle) const;
    TelemetryModel *m_model;
    QUdpSocket m_socket;
    QUdpSocket *m_reply = nullptr;
    QTimer m_refresh, m_timeout;
    quint64 m_session = 0;
    mavlink_status_t m_tx{};
    QMap<int, QString> m_results;
    QString m_channelError;
    int m_vehicle = -1, m_attempt = 0;
    quint16 m_command = 0;
    float m_altitude = 0;
    bool m_inProgress = false;
};
