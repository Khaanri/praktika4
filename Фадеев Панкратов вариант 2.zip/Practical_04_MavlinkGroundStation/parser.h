#pragma once
#include <QByteArray>
#include <QString>
#include "third_party/mavlink/lab/mavlink.h"

namespace Lab {
constexpr quint16 StationPort = 14540;
constexpr quint8 StationId = 255;
constexpr quint8 StationComponent = 190;
constexpr quint8 Component = 1;
inline quint16 simulatorPort(int system) { return 14550 + system; }
}
class MavlinkMessageParser {
public:
    static bool read(const QByteArray &bytes, mavlink_message_t &message, QString &error);
    static QByteArray bytes(const mavlink_message_t &message);
};
