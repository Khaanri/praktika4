#include "mainwindow.h"
#include "uavsimulator.h"
#include "simulatorwindow.h"
#include <QNetworkDatagram>
#include <QtTest>
#include <QtWidgets>
#include <QtCharts/QLineSeries>

class Checks : public QObject {
    Q_OBJECT
private slots:
    void packetSequence();
    void invalidFrames();
    void invalidPositionOverUdp();
    void reorderedTelemetry();
    void transactionIsolation();
    void reconnectAndControls();
    void landingAndIndependentProcess();
    void integratedStation();
};

void Checks::packetSequence()
{
    TelemetryModel model;
    auto inject = [&](quint8 seq) {
        mavlink_message_t frame{};
        mavlink_status_t tx{}; tx.current_tx_seq = seq;
        mavlink_msg_heartbeat_pack_status(1,1,&tx,&frame,2,3,1,4,MAV_STATE_ACTIVE);
        model.receive(frame,"127.0.0.1",14551);
    };
    inject(10); inject(13);
    const Vehicle &vehicle = model.vehicles().cbegin().value();
    QCOMPARE(vehicle.lost,2u);
    inject(13); QCOMPARE(vehicle.lost,2u);
    inject(12); QCOMPARE(vehicle.lost,1u);
    inject(11); QCOMPARE(vehicle.lost,0u);
    model.reset(); inject(254); inject(255); inject(0); inject(1);
    QCOMPARE(model.vehicles().cbegin()->lost,0u);
}

void Checks::invalidFrames()
{
    mavlink_message_t hb{}, decoded{};
    mavlink_status_t tx{};
    mavlink_msg_heartbeat_pack_status(1,1,&tx,&hb,2,3,1,4,MAV_STATE_ACTIVE);
    QByteArray bytes = MavlinkMessageParser::bytes(hb);
    QString error;
    QVERIFY(MavlinkMessageParser::read(bytes,decoded,error));
    QVERIFY(!MavlinkMessageParser::read(bytes.chopped(1),decoded,error));
    bytes[bytes.size()-1] ^= 1;
    QVERIFY(!MavlinkMessageParser::read(bytes,decoded,error));
    QCOMPARE(error, "Ошибка CRC");
}

void Checks::invalidPositionOverUdp()
{
    TelemetryModel model;
    MavlinkManager manager(&model);
    QVERIFY(manager.open());
    QUdpSocket source;
    QVERIFY(source.bind(QHostAddress::LocalHost, Lab::simulatorPort(1), QUdpSocket::DontShareAddress));
    mavlink_status_t tx{};
    quint32 bootMs = 100;
    auto position = [&](int altitudeMm) {
        mavlink_message_t msg{};
        mavlink_msg_global_position_int_pack_status(1,1,&tx,&msg,bootMs++,557522200,376155600,
            altitudeMm,0,0,0,0,UINT16_MAX);
        return MavlinkMessageParser::bytes(msg);
    };
    auto write = [&](const QByteArray &bytes) {
        QCOMPARE(source.writeDatagram(bytes,QHostAddress::LocalHost,Lab::StationPort),qint64(bytes.size()));
    };
    write(position(150000));
    QTRY_COMPARE(model.vehicles().size(),1);
    const auto &v = model.vehicles().cbegin().value();
    QCOMPARE(v.altitude,150.0);
    auto corrupt = position(999000); corrupt[corrupt.size()-1] ^= 1;
    write(corrupt);
    QTRY_COMPARE(v.errors,1u);
    QCOMPARE(v.received,1u); QCOMPARE(v.altitude,150.0); QCOMPARE(v.track.size(),1);
    write(position(151000).chopped(1));
    QTRY_COMPARE(v.errors,2u); QCOMPARE(v.altitude,150.0);
    write(position(152000));
    QTRY_COMPARE(v.received,2u); QCOMPARE(v.altitude,152.0);
}

void Checks::integratedStation()
{
    MainWindow window;
    window.show();
    UavSimulator first(1), second(2);
    auto *table = window.findChild<QTableWidget *>("vehicles");
    auto *takeoff = window.findChild<QPushButton *>("takeoff");
    auto *link = window.findChild<QLabel *>("link");
    auto *metrics = window.findChild<QLabel *>("metrics");
    auto *position = window.findChild<QLabel *>("position");
    auto *result = window.findChild<QLabel *>("result");
    auto *scene = window.findChild<QGraphicsView *>("map")->scene();
    auto *log = window.findChild<QListWidget *>("log");
    auto hasLog = [log](const QString &s){ return !log->findItems(s,Qt::MatchContains).isEmpty(); };
    QVERIFY(link->text().contains("Связь отсутствует"));
    QVERIFY(link->text().contains("порт закрыт"));
    QVERIFY(!takeoff->isEnabled());
    window.findChild<QPushButton *>("open")->click();
    QVERIFY(link->text().contains("14540 открыт"));
    QVERIFY(first.start()); QVERIFY(second.start());
    QTRY_COMPARE(table->rowCount(),2);
    QTRY_COMPARE(table->item(0,6)->text(),"Online");
    QTRY_COMPARE(table->item(1,6)->text(),"Online");
    QCOMPARE(table->item(0,4)->text(),"14551"); QCOMPARE(table->item(1,4)->text(),"14552");
    QTRY_VERIFY(metrics->text().contains("Телеметрия 10 Гц"));
    QTRY_VERIFY(position->text().contains("GUIDED"));
    const auto validMetric = [&]{
        return QRegularExpression("Принято (\\d+)").match(metrics->text()).captured(1).toInt();
    };
    const int received = validMetric();
    const auto startPosition = position->text();
    QTRY_VERIFY(validMetric() > received);
    QCOMPARE(position->text(), startPosition);
    auto markerPositions = [scene]{
        QMap<QGraphicsItem*,QPointF> positions;
        for (auto *item : scene->items()) if (item->type() == QGraphicsEllipseItem::Type)
            positions.insert(item,item->pos());
        return positions;
    };
    auto markers = markerPositions(); QCOMPARE(markers.size(),2);
    QCOMPARE(markerPositions(),markers);
    QCOMPARE(markerPositions().keys(),markers.keys());

    first.skipTwo(); QTRY_VERIFY(metrics->text().contains("Потеряно 2 "));
    first.corrupt(); QTRY_VERIFY(metrics->text().contains("Ошибок 1 "));
    QVERIFY(hasLog("Ошибка CRC"));
    auto countAfterError = validMetric();
    QTRY_VERIFY(validMetric() > countAfterError);
    window.findChild<QSpinBox *>("altitude")->setValue(80);
    QSignalSpy commands1(&first,&UavSimulator::commandReceived);
    QSignalSpy commands2(&second,&UavSimulator::commandReceived);
    takeoff->click(); QTRY_VERIFY(result->text().contains("Команда принята"));
    QCOMPARE(commands1.size(),1); QCOMPARE(commands1[0][0].toInt(),22);
    QCOMPARE(commands1[0][2].toFloat(),80.0f); QCOMPARE(commands2.size(),0);
    QTRY_VERIFY(markerPositions() != markers);
    QCOMPARE(markerPositions().keys(),markers.keys());
    table->selectRow(1);
    QCOMPARE(result->text(),"Команд нет");
    takeoff->click(); QTRY_VERIFY(result->text().contains("Команда принята"));
    table->selectRow(0);
    first.dropAcks(1);
    takeoff->click(); QTRY_COMPARE_WITH_TIMEOUT(commands1.size(),3,1800);
    QTRY_VERIFY(result->text().contains("Команда принята"));
    QCOMPARE(commands1[1][1].toInt(),0); QCOMPARE(commands1[2][1].toInt(),1);

    first.dropAcks(-1); QElapsedTimer elapsed; elapsed.start(); takeoff->click();
    QTRY_VERIFY_WITH_TIMEOUT(result->text().contains("Подтверждение не получено"),3700);
    qInfo() << "No ACK:" << elapsed.elapsed() << "ms.";
    QCOMPARE(commands1.size(),6);
    for (int i = 0; i < 3; ++i) QCOMPARE(commands1[3+i][1].toInt(),i);
    QTest::qWait(1100); QCOMPARE(commands1.size(),6);
    first.dropAcks(0);
    if (const auto path = qEnvironmentVariable("LAB_SCREENSHOT"); !path.isEmpty()) {
        takeoff->click(); QTRY_VERIFY(result->text().contains("Команда принята"));
        QVERIFY(window.grab().save(path));
    }
    first.fault(true); QTRY_VERIFY(position->text().contains("ОТКАЗ ДАТЧИКА"));
    takeoff->click(); QTRY_VERIFY(result->text().contains("Команда отклонена"));
    first.fault(false);
    first.heartbeatEnabled(false);
    QTRY_COMPARE_WITH_TIMEOUT(table->item(0,6)->text(),"Offline",3600);
    QVERIFY(!takeoff->isEnabled()); QVERIFY(link->text().contains("Связь потеряна"));
    QVERIFY(metrics->text().contains("Телеметрия 10 Гц") || metrics->text().contains("Телеметрия 9 Гц") ||
            metrics->text().contains("Телеметрия 11 Гц"));
    QCOMPARE(table->item(1,6)->text(),"Online");
    first.heartbeatEnabled(true); QTRY_COMPARE(table->item(0,6)->text(),"Online");
    first.stop(); QTRY_COMPARE_WITH_TIMEOUT(table->item(0,6)->text(),"Offline",3600);
    QVERIFY(metrics->text().contains("Телеметрия 0 Гц"));
    QVERIFY(!takeoff->isEnabled()); QVERIFY(first.start());
    QTRY_COMPARE(table->item(0,6)->text(),"Online"); QVERIFY(takeoff->isEnabled());
    table->selectRow(1); QTRY_VERIFY(position->text().contains("БПЛА 2"));
    takeoff->click(); QTRY_COMPARE(commands2.size(),2);
    QTRY_VERIFY(result->text().contains("БПЛА 2 — Команда принята"));
}
void Checks::reorderedTelemetry()
{
    TelemetryModel model;
    mavlink_message_t msg{};
    mavlink_status_t tx{};
    auto position = [&](int seq, quint32 time, int altitude){
        tx.current_tx_seq = seq;
        mavlink_msg_global_position_int_pack_status(1,1,&tx,&msg,time,550000000,370000000,
            altitude*1000,0,0,0,0,UINT16_MAX);
        model.receive(msg,"127.0.0.1",14551);
    };
    auto heartbeat = [&](int seq, uint8_t state){
        tx.current_tx_seq = seq;
        mavlink_msg_heartbeat_pack_status(1,1,&tx,&msg,2,3,1,4,state);
        model.receive(msg,"127.0.0.1",14551);
    };
    position(12,1000,150);
    heartbeat(11,MAV_STATE_ACTIVE);
    auto &v = model.vehicles().cbegin().value();
    QVERIFY(v.online);
    auto stamp = v.heartbeatMs;
    QTest::qWait(15);
    heartbeat(11,MAV_STATE_ACTIVE);
    QCOMPARE(v.heartbeatMs,stamp);
    position(15,1300,153); QCOMPARE(v.lost,2u);
    position(13,1100,151); position(14,1200,152);
    QCOMPARE(v.lost,0u); QCOMPARE(v.altitude,153.); QCOMPARE(v.track.size(),2);
    heartbeat(16,MAV_STATE_CRITICAL); heartbeat(11,MAV_STATE_ACTIVE); QVERIFY(v.critical);
    QSignalSpy restarts(&model,&TelemetryModel::restarted);
    heartbeat(0,MAV_STATE_BOOT); position(1,0,150); heartbeat(2,MAV_STATE_ACTIVE);
    QCOMPARE(restarts.size(),1); QCOMPARE(v.altitude,150.); QVERIFY(v.online); QVERIFY(!v.critical);
    QCOMPARE(v.track.size(),1); QCOMPARE(v.lost,0u);
    for (int i=0; i<420; ++i) position((3+i)%256,100*(i+1),150);
    QCOMPARE(v.track.size(),300); QCOMPARE(v.heights.size(),300); QCOMPARE(v.lost,0u);
}

void Checks::transactionIsolation()
{
    TelemetryModel model;
    MavlinkManager station(&model);
    QVERIFY(station.open());
    QUdpSocket peer;
    QVERIFY(peer.bind(QHostAddress::LocalHost,Lab::simulatorPort(1),QUdpSocket::DontShareAddress));
    mavlink_status_t tx{};
    mavlink_message_t msg{};
    auto beat = [&] {
        mavlink_msg_heartbeat_pack_status(1,1,&tx,&msg,2,3,1,4,MAV_STATE_ACTIVE);
        peer.writeDatagram(MavlinkMessageParser::bytes(msg),QHostAddress::LocalHost,Lab::StationPort);
    };
    const int key = TelemetryModel::key(1,1);
    beat(); QTRY_VERIFY(!model.vehicles().isEmpty() && model.vehicles()[key].online);
    QTimer beats; connect(&beats,&QTimer::timeout,&peer,beat); beats.start(500);
    auto ack = [&](int port, int result, int command = MAV_CMD_NAV_TAKEOFF, int target = Lab::StationId) {
        mavlink_msg_command_ack_pack_status(1,1,&tx,&msg,command,result,0,0,target,Lab::StationComponent);
        peer.writeDatagram(MavlinkMessageParser::bytes(msg),QHostAddress::LocalHost,port);
    };
    station.send(key,MAV_CMD_NAV_TAKEOFF,80);
    QTRY_VERIFY(peer.hasPendingDatagrams());
    const auto oldPort = peer.receiveDatagram().senderPort();
    ack(oldPort,MAV_RESULT_ACCEPTED);
    QTRY_VERIFY(!station.busy());
    station.send(key,MAV_CMD_NAV_TAKEOFF,90);
    QTRY_VERIFY(peer.hasPendingDatagrams());
    const auto port = peer.receiveDatagram().senderPort();
    QVERIFY(port != oldPort);
    ack(oldPort,MAV_RESULT_ACCEPTED);
    ack(port,MAV_RESULT_DENIED,MAV_CMD_NAV_LAND);
    ack(port,MAV_RESULT_DENIED,MAV_CMD_NAV_TAKEOFF,99);
    QTest::qWait(60); QVERIFY(station.busy());
    station.send(key,MAV_CMD_NAV_LAND,0); QVERIFY(!peer.hasPendingDatagrams());
    ack(port,MAV_RESULT_IN_PROGRESS);
    QTRY_VERIFY(station.status(key).contains("выполняется"));
    QTest::qWait(1200); QVERIFY(station.busy()); QVERIFY(!peer.hasPendingDatagrams());
    ack(port,MAV_RESULT_DENIED);
    QTRY_VERIFY(!station.busy()); QVERIFY(station.status(key).contains("отклонена"));
    station.send(key,MAV_CMD_NAV_TAKEOFF,80);
    QTRY_VERIFY(peer.hasPendingDatagrams());
    const auto progressPort = peer.receiveDatagram().senderPort();
    ack(progressPort,MAV_RESULT_IN_PROGRESS);
    QTRY_VERIFY(station.status(key).contains("выполняется"));
    QTRY_VERIFY_WITH_TIMEOUT(!station.busy(),11200);
    QVERIFY(station.status(key).contains("Итоговое подтверждение не получено"));
    QVERIFY(!peer.hasPendingDatagrams());
    station.send(key,MAV_CMD_NAV_TAKEOFF,501); QVERIFY(!station.busy()); QVERIFY(!peer.hasPendingDatagrams());
    station.send(key,MAV_CMD_NAV_LAND,0);
    QTRY_VERIFY(peer.hasPendingDatagrams());
    const auto abandoned = peer.receiveDatagram().senderPort();
    station.close(); QVERIFY(station.open()); beat();
    QTRY_VERIFY(!model.vehicles().isEmpty() && model.vehicles()[key].online);
    QCOMPARE(station.status(key),"Команд нет");
    ack(abandoned,MAV_RESULT_ACCEPTED); QTest::qWait(1100);
    QVERIFY(!station.busy()); QVERIFY(!peer.hasPendingDatagrams());
    QCOMPARE(station.status(key),"Команд нет");
}

void Checks::reconnectAndControls()
{
    MainWindow station; SimulatorWindow simulator;
    station.show(); simulator.show();
    auto *open = station.findChild<QPushButton *>("open");
    auto *close = station.findChild<QPushButton *>("closeChannel");
    auto *takeoff = station.findChild<QPushButton *>("takeoff");
    auto *link = station.findChild<QLabel *>("link");
    auto *result = station.findChild<QLabel *>("result");
    auto *table = station.findChild<QTableWidget *>("vehicles");
    auto *one = simulator.findChild<QGroupBox *>("sim1");
    auto *two = simulator.findChild<QGroupBox *>("sim2");
    auto *start = one->findChild<QPushButton *>("start");
    auto *stop = one->findChild<QPushButton *>("stop");
    auto *ack = one->findChild<QComboBox *>("ack");
    QVERIFY(start->isEnabled()); QVERIFY(!stop->isEnabled()); QVERIFY(!ack->isEnabled());
    QUdpSocket occupied;
    QVERIFY(occupied.bind(QHostAddress::LocalHost,Lab::StationPort,QUdpSocket::DontShareAddress));
    open->click(); QVERIFY(link->text().contains("Не удалось открыть")); QVERIFY(open->isEnabled());
    occupied.close();
    two->findChild<QPushButton *>("start")->click();
    open->click(); QTRY_COMPARE(table->rowCount(),1);
    QCOMPARE(table->item(table->currentRow(),1)->text(),"2");
    QVERIFY(occupied.bind(QHostAddress::LocalHost,Lab::simulatorPort(1),QUdpSocket::DontShareAddress));
    start->click(); QVERIFY(start->isEnabled()); QVERIFY(!stop->isEnabled());
    QVERIFY(one->findChild<QLabel *>("status")->text().contains("Ошибка порта"));
    occupied.close(); start->click();
    QTRY_COMPARE(table->rowCount(),2);
    QCOMPARE(table->item(table->currentRow(),1)->text(),"2");
    QVERIFY(!start->isEnabled()); QVERIFY(stop->isEnabled()); QVERIFY(ack->isEnabled());
    table->selectRow(0); QTRY_VERIFY(takeoff->isEnabled());
    ack->setCurrentIndex(1); takeoff->click();
    QTRY_COMPARE(ack->currentIndex(),0);
    auto *sensor = one->findChildren<QCheckBox *>().first();
    sensor->setChecked(true); // Повтор должен вернуть исходный результат уже выполненной команды.
    table->selectRow(1); QVERIFY(!takeoff->isEnabled());
    QVERIFY(result->text().contains("Ожидается ответ БПЛА 1"));
    QTRY_VERIFY(takeoff->isEnabled()); QCOMPARE(result->text(),"Команд нет");
    table->selectRow(0); QVERIFY(result->text().contains("Команда принята"));
    sensor->setChecked(false);
    table->clearSelection(); QVERIFY(!takeoff->isEnabled());
    QTest::qWait(200); QVERIFY(!takeoff->isEnabled());
    table->selectRow(0); QVERIFY(takeoff->isEnabled());
    station.resize(500,420); QTest::qWait(100);
    auto *scroll = station.findChild<QScrollArea *>();
    QVERIFY(station.width() <= 510); QVERIFY(scroll->verticalScrollBar()->maximum() > 0);
    scroll->ensureWidgetVisible(takeoff);
    QVERIFY(scroll->viewport()->rect().contains(takeoff->mapTo(scroll->viewport(),takeoff->rect().center())));
    station.resize(1100,800); QTest::qWait(100);
    QVERIFY(scroll->horizontalScrollBar()->maximum() == 0);
    ack->setCurrentIndex(2); takeoff->click(); close->click();
    QCOMPARE(table->rowCount(),0); QVERIFY(!takeoff->isEnabled()); QCOMPARE(result->text(),"Команд нет");
    stop->click(); QVERIFY(!stop->isEnabled()); QCOMPARE(ack->currentIndex(),0);
    open->click(); start->click(); QTRY_COMPARE(table->rowCount(),2);
    QTRY_COMPARE(table->item(0,6)->text(),"Online");
    if (const auto dir = qEnvironmentVariable("LAB_REVIEW_IMAGES"); !dir.isEmpty()) {
        QVERIFY(simulator.grab().save(dir+"/emulator.png"));
        station.resize(500,420); QTest::qWait(150); QVERIFY(station.grab().save(dir+"/compact.png"));
    }
}

void Checks::landingAndIndependentProcess()
{
    MainWindow station; station.show();
    station.findChild<QPushButton *>("open")->click();
    QProcess child;
    auto env = QProcessEnvironment::systemEnvironment();
    env.insert("LAB_CHECK_EMULATOR_CHILD","1");
    child.setProcessEnvironment(env);
    child.start(QCoreApplication::applicationFilePath(),{"-platform","offscreen"});
    QVERIFY(child.waitForStarted());
    struct Cleanup {
        QProcess &child;
        ~Cleanup(){ child.terminate(); if (!child.waitForFinished(1200)) { child.kill(); child.waitForFinished(); } }
    } cleanup{child};
    auto *takeoff = station.findChild<QPushButton *>("takeoff");
    auto *land = station.findChild<QPushButton *>("land");
    auto *pos = station.findChild<QLabel *>("position");
    auto *result = station.findChild<QLabel *>("result");
    QTRY_VERIFY(takeoff->isEnabled()); takeoff->click();
    QTRY_VERIFY(result->text().contains("Команда принята"));
    QTRY_VERIFY(!pos->text().contains("Высота 150.0 м"));
    land->click(); QTRY_VERIFY(result->text().contains("Команда принята"));
    QTRY_VERIFY(pos->text().contains("Высота 150.0 м"));
    auto ground = pos->text(); QTest::qWait(300); QCOMPARE(pos->text(),ground);
}

int main(int argc, char **argv)
{
    QApplication app(argc, argv);
    if (qEnvironmentVariableIsSet("LAB_CHECK_EMULATOR_CHILD")) {
        SimulatorWindow window;
        window.show();
        window.findChild<QGroupBox *>("sim1")->findChild<QPushButton *>("start")->click();
        return app.exec();
    }
    Checks checks;
    return QTest::qExec(&checks, argc, argv);
}
#include "checks.moc"
