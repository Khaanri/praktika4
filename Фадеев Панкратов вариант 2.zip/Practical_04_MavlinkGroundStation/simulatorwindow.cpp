#include "simulatorwindow.h"
#include "uavsimulator.h"
#include <QtWidgets>

SimulatorWindow::SimulatorWindow(QWidget *parent) : QWidget(parent)
{
    setWindowTitle("Эмулятор БПЛА");
    auto *layout = new QHBoxLayout(this);
    for (int system : {1, 2}) {
        auto *sim = new UavSimulator(system, this);
        auto *box = new QGroupBox(QString("БПЛА %1 · UDP %2").arg(system).arg(Lab::simulatorPort(system)));
        box->setObjectName(QString("sim%1").arg(system));
        auto *form = new QVBoxLayout(box);
        auto button = [form](const QString &name, const QString &text) {
            auto *b = new QPushButton(text); b->setObjectName(name); form->addWidget(b); return b;
        };
        auto *start = button("start","Запустить БПЛА");
        auto *stop = button("stop","Отключить БПЛА");
        auto *corrupt = button("corrupt","Повредить пакет");
        auto *skip = button("skip","Пропустить два пакета");
        connect(start,&QPushButton::clicked,sim,&UavSimulator::start);
        connect(stop,&QPushButton::clicked,sim,&UavSimulator::stop);
        connect(corrupt,&QPushButton::clicked,sim,&UavSimulator::corrupt);
        connect(skip,&QPushButton::clicked,sim,&UavSimulator::skipTwo);
        auto *drop = new QComboBox; drop->setObjectName("ack");
        drop->addItems({"Отвечать на команды","Пропустить следующий ACK","Пропускать все ACK"});
        form->addWidget(drop);
        connect(drop,&QComboBox::currentIndexChanged,sim,[sim](int index){ sim->dropAcks(index == 2 ? -1 : index); });
        connect(sim,&UavSimulator::ackPolicyChanged,drop,[drop](int n) {
            const QSignalBlocker blocker(drop); drop->setCurrentIndex(n < 0 ? 2 : (n > 0 ? 1 : 0));
        });
        auto *fault = new QCheckBox("Отказ датчика");
        auto *mute = new QCheckBox("Приостановить HEARTBEAT");
        form->addWidget(fault); form->addWidget(mute);
        connect(fault,&QCheckBox::toggled,sim,&UavSimulator::fault);
        connect(mute,&QCheckBox::toggled,sim,[sim](bool on){ sim->heartbeatEnabled(!on); });
        auto *status = new QLabel("Остановлен"); status->setObjectName("status");
        status->setWordWrap(true); form->addWidget(status);
        connect(sim,&UavSimulator::event,status,&QLabel::setText);
        auto update = [=](bool running){
            start->setEnabled(!running); stop->setEnabled(running);
            corrupt->setEnabled(running); skip->setEnabled(running); drop->setEnabled(running);
            fault->setEnabled(running); mute->setEnabled(running);
            if (!running) { fault->setChecked(false); mute->setChecked(false); }
        };
        connect(sim,&UavSimulator::runningChanged,box,update);
        update(false); layout->addWidget(box);
    }
}
