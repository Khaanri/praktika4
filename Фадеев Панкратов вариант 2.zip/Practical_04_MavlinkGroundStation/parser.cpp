#include "parser.h"

bool MavlinkMessageParser::read(const QByteArray &bytes, mavlink_message_t &message, QString &error)
{
    if (bytes.size() < 13 || quint8(bytes[0]) != MAVLINK_STX || bytes[2] != 0 ||
        bytes.size() != 12 + quint8(bytes[1])) {
        error = "Неверная длина или заголовок";
        return false;
    }
    const quint32 id = quint8(bytes[7]) | (quint32(quint8(bytes[8])) << 8) |
                       (quint32(quint8(bytes[9])) << 16);
    const auto *definition = mavlink_get_msg_entry(id);
    if (!definition || quint8(bytes[1]) > definition->max_msg_len) {
        error = "Неизвестный тип или неверная длина";
        return false;
    }
    mavlink_message_t buffer{};
    mavlink_status_t state{}, result{};
    uint8_t framing = MAVLINK_FRAMING_INCOMPLETE;
    for (char byte : bytes)
        framing = mavlink_frame_char_buffer(&buffer, &state, quint8(byte), &message, &result);
    if (framing != MAVLINK_FRAMING_OK) {
        error = "Ошибка CRC";
        return false;
    }
    return true;
}

QByteArray MavlinkMessageParser::bytes(const mavlink_message_t &message)
{
    uint8_t bytes[MAVLINK_MAX_PACKET_LEN];
    const auto length = mavlink_msg_to_send_buffer(bytes, &message);
    return QByteArray(reinterpret_cast<const char *>(bytes), length);
}
