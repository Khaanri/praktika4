#pragma once
#include "parser.h"
#include <QDateTime>
#include <QElapsedTimer>
#include <QMap>
#include <QObject>
#include <QPointF>
#include <QQueue>
#include <QSet>
#include <optional>

struct Vehicle {
    quint8 system = 0, component = 0;
    QString address, mode = "—";
    quint16 port = 0;
    QTime lastClock;
    qint64 positionMs = -1, packetMs = -1, heartbeatMs = -1, sequence = -1, heartbeatSequence = -1;
    bool online = false, critical = false;
    quint64 received = 0, errors = 0, lost = 0, revision = 0;
    QSet<qint64> gaps, seen;
    QQueue<qint64> positionsMs;
    double latitude = 0, longitude = 0, altitude = 0;
    QList<QPointF> track, heights;
    std::optional<quint32> lastBootMs;
    qint64 bootNoticeMs = -1;
};

class TelemetryModel : public QObject {
    Q_OBJECT
public:
    explicit TelemetryModel(QObject *parent = nullptr);
    static int key(int system, int component) { return system * 256 + component; }
    const QMap<int, Vehicle> &vehicles() const { return m_vehicles; }
    qint64 now() const { return m_clock.elapsed(); }
    void receive(const mavlink_message_t &msg, const QString &address, quint16 port);
    void errorFrom(quint16 port);
    void refresh();
    void reset();
signals:
    void changed();
    void restarted(int key);
    void event(QString message);
private:
    std::optional<qint64> observe(Vehicle &v, quint8 seq);
    QMap<int, Vehicle> m_vehicles;
    QMap<quint16, quint64> m_unidentifiedErrors;
    QElapsedTimer m_clock;
};
