#include "mavlinkmanager.h"
#include <QNetworkDatagram>
#include <cmath>

MavlinkManager::MavlinkManager(TelemetryModel *model, QObject *parent)
    : QObject(parent), m_model(model)
{
    connect(&m_socket, &QUdpSocket::readyRead, this, [this]{ read(&m_socket); });
    connect(&m_refresh, &QTimer::timeout, this, [this] {
        m_model->refresh();
        if (busy() && !reachable(m_vehicle)) finish("Связь потеряна");
    });
    connect(m_model, &TelemetryModel::restarted, this, [this](int key) {
        m_results.remove(key);
        if (activeVehicle() == key) finish("Эмулятор перезапущен");
    });
    m_timeout.setSingleShot(true);
    m_timeout.setTimerType(Qt::PreciseTimer);
    connect(&m_timeout, &QTimer::timeout, this, [this] {
        if (!busy()) return;
        if (m_inProgress) finish("Итоговое подтверждение не получено");
        else if (m_attempt == 3) finish("Подтверждение не получено");
        else attempt();
    });
}

bool MavlinkManager::open()
{
    if (isOpen()) return true;
    m_channelError.clear();
    if (!m_socket.bind(QHostAddress::LocalHost, Lab::StationPort, QUdpSocket::DontShareAddress)) {
        m_channelError = "Не удалось открыть UDP 14540: " + m_socket.errorString();
        emit event(m_channelError);
        m_socket.close();
        emit changed();
        return false;
    }
    m_refresh.start(100);
    emit event("Канал открыт");
    emit changed();
    return true;
}

void MavlinkManager::close()
{
    if (busy()) finish("Канал закрыт");
    ++m_session;
    m_refresh.stop();
    m_socket.close();
    m_results.clear();
    m_channelError.clear();
    m_model->reset();
    emit event("Канал закрыт");
    emit changed();
}

void MavlinkManager::read(QUdpSocket *socket)
{
    while (socket->state() == QAbstractSocket::BoundState && socket->hasPendingDatagrams()) {
        const auto d = socket->receiveDatagram();
        const int system = d.senderPort() - 14550;
        if (!isOpen() || !d.isValid() || d.senderAddress() != QHostAddress::LocalHost ||
            (system != 1 && system != 2)) continue;
        mavlink_message_t msg{};
        QString error;
        if (!MavlinkMessageParser::read(d.data(), msg, error)) {
            m_model->errorFrom(d.senderPort());
            emit event(QString("БПЛА %1 — %2").arg(system).arg(error));
            continue;
        }
        if (msg.sysid != system || msg.compid != Lab::Component) continue;
        if (socket != &m_socket && msg.msgid != MAVLINK_MSG_ID_COMMAND_ACK) continue;
        if (msg.msgid == MAVLINK_MSG_ID_COMMAND_LONG) continue;
        m_model->receive(msg, d.senderAddress().toString(), d.senderPort());
        const int key = TelemetryModel::key(msg.sysid, msg.compid);
        if (msg.msgid == MAVLINK_MSG_ID_COMMAND_ACK && socket == m_reply &&
            key == m_vehicle && reachable(key)) handleAck(msg);
    }
}

bool MavlinkManager::reachable(int key) const
{
    auto it = m_model->vehicles().constFind(key);
    return isOpen() && it != m_model->vehicles().cend() && it->online &&
           m_model->now() - it->heartbeatMs <= 3000;
}

void MavlinkManager::send(int vehicle, quint16 command, double altitude)
{
    if (busy()) return;
    m_vehicle = vehicle;
    if (!reachable(vehicle)) { report("Команда недоступна: нет связи"); return; }
    if (command != MAV_CMD_NAV_TAKEOFF && command != MAV_CMD_NAV_LAND) {
        report("Команда не поддерживается"); return;
    }
    if (command == MAV_CMD_NAV_TAKEOFF && (!std::isfinite(altitude) || altitude < 10 || altitude > 500)) {
        report("Высота взлёта должна быть от 10 до 500 м"); return;
    }
    // В COMMAND_ACK нет номера операции. На локальном стенде отдельный
    // обратный порт отличает ответы двух последовательных одноимённых команд.
    m_reply = new QUdpSocket(this);
    if (!m_reply->bind(QHostAddress::LocalHost, 0, QUdpSocket::DontShareAddress)) {
        finish("Не удалось открыть порт подтверждения"); return;
    }
    auto *socket = m_reply;
    const auto session = m_session;
    connect(socket, &QUdpSocket::readyRead, this, [this, socket, session] {
        if (session == m_session) read(socket);
        else while (socket->hasPendingDatagrams()) socket->receiveDatagram();
    });
    m_command = command;
    m_altitude = command == MAV_CMD_NAV_LAND ? 0 : float(altitude);
    m_attempt = 0;
    m_inProgress = false;
    attempt();
}

void MavlinkManager::attempt()
{
    if (!reachable(m_vehicle)) { finish("Связь потеряна"); return; }
    const Vehicle &v = m_model->vehicles().constFind(m_vehicle).value();
    mavlink_message_t msg{};
    mavlink_msg_command_long_pack_status(Lab::StationId, Lab::StationComponent, &m_tx, &msg,
        v.system, v.component, m_command, m_attempt, 0, NAN, 0, NAN, NAN, NAN, m_altitude);
    const auto bytes = MavlinkMessageParser::bytes(msg);
    if (m_reply->writeDatagram(bytes, QHostAddress::LocalHost, v.port) != bytes.size()) {
        finish("Ошибка отправки"); return;
    }
    ++m_attempt;
    m_timeout.start(1000);
    report(QString("команда %1, попытка %2 из 3").arg(m_command).arg(m_attempt));
}

void MavlinkManager::report(const QString &text)
{
    const auto result = QString("БПЛА %1 — %2").arg(m_vehicle / 256).arg(text);
    m_results.insert(m_vehicle,result);
    emit event(result);
    emit changed();
}

void MavlinkManager::finish(const QString &text)
{
    m_timeout.stop();
    // Оставляем прежний порт занятым на время запаздывающих ответов стенда.
    auto *retired = m_reply;
    m_reply = nullptr;
    if (retired) QTimer::singleShot(10000, retired, &QObject::deleteLater);
    m_inProgress = false;
    report(text);
}

void MavlinkManager::handleAck(const mavlink_message_t &msg)
{
    mavlink_command_ack_t ack{};
    mavlink_msg_command_ack_decode(&msg, &ack);
    if (ack.command != m_command || ack.target_system != Lab::StationId ||
        ack.target_component != Lab::StationComponent) return;
    switch (ack.result) {
    case MAV_RESULT_ACCEPTED: finish("Команда принята"); break;
    case MAV_RESULT_TEMPORARILY_REJECTED: finish("Команда временно отклонена"); break;
    case MAV_RESULT_DENIED: finish("Команда отклонена"); break;
    case MAV_RESULT_UNSUPPORTED: finish("Команда не поддерживается"); break;
    case MAV_RESULT_FAILED: finish("Ошибка выполнения"); break;
    case MAV_RESULT_IN_PROGRESS:
        m_inProgress = true;
        m_timeout.start(10000);
        report("Команда выполняется");
        break;
    default: finish(QString("Неизвестный результат (%1)").arg(ack.result)); break;
    }
}
