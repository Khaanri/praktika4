#pragma once
#include <QWidget>
class SimulatorWindow : public QWidget {
public:
    explicit SimulatorWindow(QWidget *parent = nullptr);
};
